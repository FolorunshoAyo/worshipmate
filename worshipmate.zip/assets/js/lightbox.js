"use strict";
/*!lightbox.js | Friendkit | © Css Ninja. 2019-2020*/
$(document).ready(function () {
  // if ($("[data-fancybox]").length) {
  //   $("[data-fancybox]").each(function () {
  //     if ("comments" == $(this).attr("data-lightbox-type")) {
  //       var n = $(this).attr("data-fancybox");
  //       console.log(n),
  //         $(this).fancybox({
  //           baseClass: "fancybox-custom-layout",
  //           keyboard: true,
  //           infobar: true,
  //           touch: {
  //             vertical: !1,
  //           },
  //           buttons: ["close", "thumbs", "share"],
  //           animationEffect: "fade",
  //           transitionEffect: "fade",
  //           preventCaptionOverlap: !1,
  //           idleTime: !1,
  //           gutter: 0,
  //           afterShow: function (n, s) {
  //               initDropdowns(),
  //               initLightboxEmojis(),
  //               "development" === env &&
  //                 $(".fancybox-container [data-demo-src]").each(function () {
  //                   var n = $(this).attr("data-demo-src");
  //                   $(this).attr("src", n);
  //                 });
  //           },
  //         });
  //     }
  //   });
  // }
});
