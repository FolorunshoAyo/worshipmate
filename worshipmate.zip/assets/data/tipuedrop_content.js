var tipuedrop = {
    "pages": [{
        "title": "Jenna Davis",
        "thumb": "https://localhost/worshipmate/assets/img/avatars/jenna.png",
        "text": "<small>Influencer, PARIS</small>",
        "url": "/profile"
    }, {
        "title": "Dan Walker",
        "thumb": "https://localhost/worshipmate/assets/img/avatars/dan.jpg",
        "text": "<small>Developer, NY</small>",
        "url": "/profile"
    }, {
        "title": "Stella Bergmann",
        "thumb": "https://localhost/worshipmate/assets/img/avatars/stella.jpg",
        "text": "<small>Student, BERLIN</small>",
        "url": "/profile"
    }, {
        "title": "Daniel Wellington",
        "thumb": "https://localhost/worshipmate/assets/img/avatars/daniel.jpg",
        "text": "<small>Teacher, LONDON</small>",
        "url": "/profile"
    }, {
        "title": "David Kim",
        "thumb": "https://localhost/worshipmate/assets/img/avatars/david.jpg",
        "text": "<small>Developer, LA</small>",
        "url": "/profile"
    }, {
        "title": "Edward Mayers",
        "thumb": "https://localhost/worshipmate/assets/img/avatars/edward.jpeg",
        "text": "<small>Doctor, DUBLIN</small>",
        "url": "/profile"
    }, {
        "title": "Elise Walker",
        "thumb": "https://localhost/worshipmate/assets/img/avatars/elise.jpg",
        "text": "<small>Influencer, LONDON</small>",
        "url": "/profile"
    }, {
        "title": "Milly Augustine",
        "thumb": "https://localhost/worshipmate/assets/img/avatars/milly.jpg",
        "text": "<small>Lawyer, ROME</small>",
        "url": "/profile"
    }, {
        "title": "Bobby Brown",
        "thumb": "https://localhost/worshipmate/assets/img/avatars/bobby.jpg",
        "text": "<small>Designer, PARIS</small>",
        "url": "/profile"
    }, {
        "title": "Nelly Schwartz",
        "thumb": "https://localhost/worshipmate/assets/img/avatars/nelly.png",
        "text": "<small>CFO, MELBOURNE</small>",
        "url": "/profile"
    }, {
        "title": "Lana Henrikssen",
        "thumb": "https://localhost/worshipmate/assets/img/avatars/lana.jpeg",
        "text": "<small>Student, HELSINKI</small>",
        "url": "/profile"
    }, {
        "title": "Gaelle Morris",
        "thumb": "https://localhost/worshipmate/assets/img/avatars/gaelle.jpeg",
        "text": "<small>Merchant, Lyon</small>",
        "url": "/profile"
    }, {
        "title": "Mike Lasalle",
        "thumb": "https://localhost/worshipmate/assets/img/avatars/mike.jpg",
        "text": "<small>Businessman, TORONTO</small>",
        "url": "/profile"
    }, {
        "title": "Rolf Krupp",
        "thumb": "https://localhost/worshipmate/assets/img/avatars/rolf.jpg",
        "text": "<small>Accountant, BERLIN</small>",
        "url": "/profile"
    }, {
        "title": "Android Studio",
        "thumb": "https://localhost/worshipmate/assets/img/vector/icons/logos/android.svg",
        "text": "<small>Technology</small>",
        "url": "/profile"
    }, {
        "title": "Angular",
        "thumb": "https://localhost/worshipmate/assets/img/vector/icons/logos/angular.svg",
        "text": "<small>Technology</small>",
        "url": "/profile"
    }, {
        "title": "Domino's Pizza",
        "thumb": "https://localhost/worshipmate/assets/img/vector/icons/logos/domino.jpg",
        "text": "<small>Pizza & Fast Food</small>",
        "url": "/profile"
    }, {
        "title": "IMDB",
        "thumb": "https://localhost/worshipmate/assets/img/vector/icons/logos/imdb.png",
        "text": "<small>Movies / Entertainment</small>",
        "url": "/profile"
    }, {
        "title": "Vuejs",
        "thumb": "https://localhost/worshipmate/assets/img/vector/icons/logos/vuejs.svg",
        "text": "<small>Technology</small>",
        "url": "/profile"
    }, {
        "title": "Reactjs",
        "thumb": "https://localhost/worshipmate/assets/img/vector/icons/logos/reactjs.svg",
        "text": "<small>Technology</small>",
        "url": "/profile"
    }, {
        "title": "Photoshop",
        "thumb": "https://localhost/worshipmate/assets/img/vector/icons/logos/photoshop.svg",
        "text": "<small>Design</small>",
        "url": "/profile"
    }, {
        "title": "WordPress",
        "thumb": "https://localhost/worshipmate/assets/img/vector/icons/logos/wordpress.svg",
        "text": "<small>Technology</small>",
        "url": "/profile"
    }]
};
