<div class="page-counts">
    <div class="like-count">
        <span>78K</span>
        <span>Likes</span>
    </div>
    <div class="follow-count">
        <span>148K</span>
        <span>Followers</span>
    </div>
</div>