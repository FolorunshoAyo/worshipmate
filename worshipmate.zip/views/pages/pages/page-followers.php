<div class="followers">
    <a class="follower">
        <img src="https://via.placeholder.com/300x300" data-demo-src="../assets/img/avatars/nelly.png" data-user-popover="9" alt="">
    </a>
    <a class="follower">
        <img src="https://via.placeholder.com/300x300" data-demo-src="../assets/img/avatars/leana.jpg" data-user-popover="15" alt="">
    </a>
    <a class="follower">
        <img src="https://via.placeholder.com/300x300" data-demo-src="../assets/img/avatars/azzouz.jpg" data-user-popover="20" alt="">
    </a>
    <a class="follower">
        <img src="https://via.placeholder.com/300x300" data-demo-src="../assets/img/avatars/elise.jpg" data-user-popover="6" alt="">
    </a>
    <a class="follower">
        <img src="https://via.placeholder.com/300x300" data-demo-src="../assets/img/avatars/david.jpg" data-user-popover="4" alt="">
    </a>
    <a class="follower">
        <img src="https://via.placeholder.com/300x300" data-demo-src="../assets/img/avatars/edward.jpeg" data-user-popover="5" alt="">
    </a>
    <a class="follower">
        <img src="https://via.placeholder.com/300x300" data-demo-src="../assets/img/avatars/dan.jpg" data-user-popover="1" alt="">
    </a>
    <a class="follower">
        <img src="https://via.placeholder.com/300x300" data-demo-src="../assets/img/avatars/brian.jpg" data-user-popover="19" alt="">
    </a>
    <a class="follower">
        <img src="https://via.placeholder.com/300x300" data-demo-src="../assets/img/avatars/milly.jpg" data-user-popover="7" alt="">
    </a>
    <a class="follower">
        <img src="https://via.placeholder.com/300x300" data-demo-src="../assets/img/avatars/daniel.jpg" data-user-popover="3" alt="">
    </a>
    <a class="follower">
        <img src="https://via.placeholder.com/300x300" data-demo-src="../assets/img/avatars/ken.jpg" data-user-popover="14" alt="">
    </a>
    <a class="follower">
        <img src="https://via.placeholder.com/300x300" data-demo-src="../assets/img/avatars/cathy.png" data-user-popover="21" alt="">
    </a>
    <a class="follower">
        <img src="https://via.placeholder.com/300x300" data-demo-src="../assets/img/avatars/bob.png" data-user-popover="22" alt="">
    </a>
    <a class="follower">
        <img src="https://via.placeholder.com/300x300" data-demo-src="../assets/img/avatars/greg.png" data-user-popover="23" alt="">
    </a>
    <a class="follower">
        <img src="https://via.placeholder.com/300x300" data-demo-src="../assets/img/avatars/hisashi.jpg" data-user-popover="24" alt="">
    </a>
</div>
<!-- Show More -->
<div class="more-followers">
    <a>Show More</a>
</div>