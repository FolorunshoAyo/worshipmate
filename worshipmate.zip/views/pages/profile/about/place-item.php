<div class="place-wrapper">
    <img src="https://via.placeholder.com/800x600" data-demo-src="assets/img/demo/unsplash/places/16.jpg" alt="">
    <div class="foot">
        <a href="#" class="place-name">Melbourne</a>
        <div class="rating">
            <i class="is-checked" data-feather="star"></i>
            <i class="is-checked" data-feather="star"></i>
            <i class="is-checked" data-feather="star"></i>
            <i class="is-checked" data-feather="star"></i>
            <i class="is-checked" data-feather="star"></i>
        </div>
    </div>
</div>