<div class="timeline-item">
    <div class="image-container">
        <img src="https://via.placeholder.com/800x600" alt="" data-demo-src="../assets/img/demo/unsplash/popovers/pages/brent.jpg">
        <div class="logo-container">
            <img src="https://via.placeholder.com/150x150" alt="" data-demo-src="../assets/img/vector/icons/logos/brent.svg" data-page-popover="6">
        </div>
    </div>
    <h3>Master Degree</h3>
    <p>Brent University</p>
    <div class="more">
        <p>Lorem ipsum sit dolor amet is a dummy text used by typographers.</p>
    </div>
    <div class="date">
        Aug 2016
    </div>
</div>