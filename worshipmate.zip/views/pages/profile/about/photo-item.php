<div class="photo-wrapper">
    <div class="photo-overlay"></div>
    <div class="small-like">
        <div class="inner">
            <div class="like-overlay"></div>
            <i data-feather="heart"></i>
        </div>
    </div>
    <img src="https://via.placeholder.com/400x400" data-demo-src="assets/img/demo/profile/about/photos/1.jpg" alt="">
</div>