<div class="video-wrapper">
    <div class="video-overlay"></div>
    <div class="video-length">02:32</div>
    <div class="small-like">
        <div class="inner">
            <div class="like-overlay"></div>
            <i data-feather="heart"></i>
        </div>
    </div>
    <img src="https://via.placeholder.com/800x600" data-demo-src="assets/img/demo/profile/about/videos/1.jpg" alt="">
    <div class="video-button" data-video-id="LTrzSSf0YlA">
        <img src="assets/img/icons/video/play.svg" alt="">
    </div>
</div>