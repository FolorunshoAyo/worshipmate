<div class="column is-3">
    <a class="friend-item has-text-centered">
        <div class="avatar-wrap">
            <div class="circle"></div>
            <div class="chat-button">
                <i data-feather="message-circle"></i>
            </div>
            <img src="https://via.placeholder.com/150x150" data-demo-src="../assets/img/avatars/milly.jpg" data-user-popover="7" alt="">
        </div>
        <h3>Milly Augustine</h3>
        <p>From Rome</p>
    </a>
</div>