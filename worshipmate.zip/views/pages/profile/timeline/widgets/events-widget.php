<div class="box-heading">
    <h4>Events</h4>
    <div class="dropdown is-neutral is-spaced is-right dropdown-trigger">
        <div>
            <div class="button">
                <i data-feather="more-vertical"></i>
            </div>
        </div>
        <div class="dropdown-menu" role="menu">
            <div class="dropdown-content">
                <a class="dropdown-item">
                    <div class="media">
                        <i data-feather="calendar"></i>
                        <div class="media-content">
                            <h3>All Events</h3>
                            <small>View all your events</small>
                        </div>
                    </div>
                </a>
                <a href="#" class="dropdown-item">
                    <div class="media">
                        <i data-feather="search"></i>
                        <div class="media-content">
                            <h3>Search</h3>
                            <small>Search for events.</small>
                        </div>
                    </div>
                </a>
                <a href="#" class="dropdown-item">
                    <div class="media">
                        <i data-feather="compass"></i>
                        <div class="media-content">
                            <h3>Suggestions</h3>
                            <small>View trendy suggestions.</small>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div>
</div>

<!-- Schedule calendar widget -->
<!-- html/partials/widgets/schedule/schedule-widget.html -->
<div class="schedule">
    <div class="schedule-day-container hidden">
        <div class="day-header day-header--large">
            <div class="day-header-bg"></div>
            <div class="day-header-close">
                <i data-feather="x"></i>
            </div>
            <div class="day-header-content">
                <div class="day-header-title">
                    <div class="day-header-title-day">24</div>
                    <div class="day-header-title-month">October</div>
                </div>
                <div class="day-header-event">Workout Session</div>
            </div>
        </div>
        <div class="day-content has-slimscroll">

            <!-- Event 1 details -->
            <!-- html/partials/widgets/schedule/event-details/event-1.html -->
            <?php
            include("../views/widgets/schedule/event-details/event.php")
            ?>
            <!-- Event 2 details -->
            <!-- html/partials/widgets/schedule/event-details/event-2.html -->
            <div id="event-2" class="event-details-wrap">
                <div class="meta-block">
                    <i class="mdi mdi-lock"></i>
                    <div class="meta">
                        <span>Private</span>
                        <span>This is a private event</span>
                    </div>
                </div>
                <div class="meta-block">
                    <i class="mdi mdi-map-marker"></i>
                    <div class="meta">
                        <span>Where</span>
                        <span>@ <a class="is-inverted">Wayne's Coffeeshop</a>, LA</span>
                    </div>
                </div>
                <div class="meta-block">
                    <i class="mdi mdi-progress-clock"></i>
                    <div class="meta">
                        <span>When</span>
                        <span>11:00am - 12:30pm</span>
                    </div>
                </div>
                <div class="participants-wrap">
                    <label>3 Participants</label>
                    <div class="participants">
                        <img src="https://via.placeholder.com/300x300" data-demo-src="../assets/img/avatars/jenna.png" alt="" data-user-popover="0">
                        <img src="https://via.placeholder.com/300x300" data-demo-src="../assets/img/avatars/edward.jpeg" alt="" data-user-popover="4">
                        <img src="https://via.placeholder.com/300x300" data-demo-src="../assets/img/avatars/rolf.jpg" alt="" data-user-popover="13">
                    </div>
                </div>
                <div class="event-description">
                    <label>Description</label>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci blanditiis commodi accusamus dolores itaque repudiandae.</p>
                </div>
                <hr>
                <div class="button-wrap">
                    <a class="button is-bold">Participating</a>
                    <a class="button is-bold">Details</a>
                </div>
            </div>
            <!-- Event 3 details -->
            <!-- html/partials/widgets/schedule/event-details/event-3.html -->
            <div id="event-3" class="event-details-wrap">
                <div class="meta-block">
                    <i class="mdi mdi-earth"></i>
                    <div class="meta">
                        <span>Public</span>
                        <span>This is a public event</span>
                    </div>
                </div>
                <div class="meta-block">
                    <i class="mdi mdi-map-marker"></i>
                    <div class="meta">
                        <span>Where</span>
                        <span>@ Frank's appartment</span>
                    </div>
                </div>
                <div class="meta-block">
                    <i class="mdi mdi-progress-clock"></i>
                    <div class="meta">
                        <span>When</span>
                        <span>08:00pm - 02:00am</span>
                    </div>
                </div>
                <div class="participants-wrap">
                    <label>29 Participants</label>
                    <div class="participants">
                        <img src="https://via.placeholder.com/300x300" data-demo-src="../assets/img/avatars/jenna.png" alt="" data-user-popover="0">
                        <img src="https://via.placeholder.com/300x300" data-demo-src="../assets/img/avatars/elise.jpg" alt="" data-user-popover="6">
                        <img src="https://via.placeholder.com/300x300" data-demo-src="../assets/img/avatars/daniel.jpg" alt="" data-user-popover="3">
                        <img src="https://via.placeholder.com/300x300" data-demo-src="../assets/img/avatars/rolf.jpg" alt="" data-user-popover="13">
                        <img src="https://via.placeholder.com/300x300" data-demo-src="../assets/img/avatars/milly.jpg" alt="" data-user-popover="7">
                        <div class="is-more">+24</div>
                    </div>
                </div>
                <div class="event-description">
                    <label>Description</label>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci blanditiis commodi accusamus dolores itaque repudiandae.</p>
                </div>
                <hr>
                <div class="button-wrap">
                    <a class="button is-bold">Participating</a>
                    <a class="button is-bold">Details</a>
                </div>
            </div>
            <!-- Event 4 details -->
            <!-- html/partials/widgets/schedule/event-details/event-4.html -->
            <div id="event-4" class="event-details-wrap">
                <div class="meta-block">
                    <i class="mdi mdi-lock"></i>
                    <div class="meta">
                        <span>Private</span>
                        <span>This is a private event</span>
                    </div>
                </div>
                <div class="meta-block">
                    <i class="mdi mdi-map-marker"></i>
                    <div class="meta">
                        <span>Where</span>
                        <span>@ <a class="is-inverted">Gold Gym</a>, LA</span>
                    </div>
                </div>
                <div class="meta-block">
                    <i class="mdi mdi-progress-clock"></i>
                    <div class="meta">
                        <span>When</span>
                        <span>05:00pm - 07:00pm</span>
                    </div>
                </div>
                <div class="participants-wrap">
                    <label>2 Participants</label>
                    <div class="participants">
                        <img src="https://via.placeholder.com/300x300" data-demo-src="../assets/img/avatars/jenna.png" alt="" data-user-popover="0">
                        <img src="https://via.placeholder.com/300x300" data-demo-src="../assets/img/avatars/lana.jpeg" alt="" data-user-popover="10">
                    </div>
                </div>
                <div class="event-description">
                    <label>Description</label>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci blanditiis commodi accusamus dolores itaque repudiandae.</p>
                </div>
                <hr>
                <div class="button-wrap">
                    <a class="button is-bold">Participating</a>
                    <a class="button is-bold">Details</a>
                </div>
            </div>
            <!-- Event 5 details -->
            <!-- html/partials/widgets/schedule/event-details/event-5.html -->
            <div id="event-5" class="event-details-wrap">
                <div class="meta-block">
                    <i class="mdi mdi-lock"></i>
                    <div class="meta">
                        <span>Private</span>
                        <span>This is a private event</span>
                    </div>
                </div>
                <div class="meta-block">
                    <i class="mdi mdi-map-marker"></i>
                    <div class="meta">
                        <span>Where</span>
                        <span>@ <a class="is-inverted">Massive Dynamics Office</a>, LA</span>
                    </div>
                </div>
                <div class="meta-block">
                    <i class="mdi mdi-progress-clock"></i>
                    <div class="meta">
                        <span>When</span>
                        <span>08:30am - 10:00am</span>
                    </div>
                </div>
                <div class="participants-wrap">
                    <label>29 Participants</label>
                    <div class="participants">
                        <img src="https://via.placeholder.com/300x300" data-demo-src="../assets/img/avatars/jenna.png" alt="" data-user-popover="0">
                        <img src="https://via.placeholder.com/300x300" data-demo-src="../assets/img/avatars/dan.jpg" alt="" data-user-popover="1">
                        <img src="https://via.placeholder.com/300x300" data-demo-src="../assets/img/avatars/edward.jpeg" alt="" data-user-popover="5">
                        <img src="https://via.placeholder.com/300x300" data-demo-src="../assets/img/avatars/mike.jpg" alt="" data-user-popover="12">
                        <img src="https://via.placeholder.com/300x300" data-demo-src="../assets/img/avatars/gaelle.jpeg" alt="" data-user-popover="11">
                        <div class="is-more">+4</div>
                    </div>
                </div>
                <div class="event-description">
                    <label>Description</label>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci blanditiis commodi accusamus dolores itaque repudiandae.</p>
                </div>
                <hr>
                <div class="button-wrap">
                    <a class="button is-bold">Participating</a>
                    <a class="button is-bold">Details</a>
                </div>
            </div>
        </div>
    </div>
    <div class="schedule-header">
        <div class="nav-icon">
            <i data-feather="chevron-left"></i>
        </div>
        <div class="month">October</div>
        <div class="nav-icon">
            <i data-feather="chevron-right"></i>
        </div>
    </div>
    <div class="schedule-calendar">
        <div class="calendar-row day-row">
            <div class="day day-name">M</div>
            <div class="day day-name">T</div>
            <div class="day day-name">W</div>
            <div class="day day-name">T</div>
            <div class="day day-name">F</div>
            <div class="day day-name">S</div>
            <div class="day day-name">S</div>
        </div>
        <div class="calendar-row">
            <div class="day">&nbsp;</div>
            <div class="day">&nbsp;</div>
            <div class="day">1</div>
            <div class="day event green" data-content="1" data-day="2" data-event="Eat at mom and dad's">2</div>
            <div class="day">3</div>
            <div class="day">4</div>
            <div class="day">5</div>
        </div>
        <div class="calendar-row">
            <div class="day">6</div>
            <div class="day event purple" data-content="2" data-day="7" data-event="Meet customer in LA">7</div>
            <div class="day">8</div>
            <div class="day">9</div>
            <div class="day">10</div>
            <div class="day">11</div>
            <div class="day">12</div>
        </div>
        <div class="calendar-row">
            <div class="day">13</div>
            <div class="day">14</div>
            <div class="day">15</div>
            <div class="day">16</div>
            <div class="day">17</div>
            <div class="day">18</div>
            <div class="day">19</div>
        </div>
        <div class="calendar-row">
            <div class="day">20</div>
            <div class="day">21</div>
            <div class="day event green" data-content="3" data-day="22" data-event="Frank's birthday">22</div>
            <div class="day">23</div>
            <div class="day event primary" data-content="4" data-day="24" data-event="Workout Session">24</div>
            <div class="day">25</div>
            <div class="day event purple" data-content="5" data-day="26" data-event="Project review">26</div>
        </div>
        <div class="calendar-row">
            <div class="day">27</div>
            <div class="day">28</div>
            <div class="day">29</div>
            <div class="day">30</div>
            <div class="day"></div>
            <div class="day"></div>
            <div class="day"></div>
        </div>
        <div class="next-fab">
            <i data-feather="chevron-down"></i>
        </div>
    </div>
    <div class="schedule-divider"></div>
    <div class="schedule-events">
        <div class="schedule-events-title">
            Upcoming events
        </div>
        <div class="schedule-event">
            <div class="event-date green">2</div>
            <div class="event-title">
                <span>Eat at mom and dad's</span>
                <span>07:30pm | Home</span>
            </div>
        </div>
        <div class="schedule-event">
            <div class="event-date purple">7</div>
            <div class="event-title">
                <span>Meet customer in LA</span>
                <span>11:00am | St Luc Café</span>
            </div>
        </div>
        <div class="schedule-event">
            <div class="event-date green">22</div>
            <div class="event-title">
                <span>Frank's birthday</span>
                <span>03:00pm | Frank's home</span>
            </div>
        </div>
        <div class="schedule-event">
            <div class="event-date primary">24</div>
            <div class="event-title">
                <span>Workout session</span>
                <span>07:00am | Gold Gym</span>
            </div>
        </div>
        <div class="schedule-event">
            <div class="event-date purple">26</div>
            <div class="event-title">
                <span>Project review</span>
                <span>08:00am | Office</span>
            </div>
        </div>
        <div class="button-wrap">
            <a class="button is-fullwidth has-icon"><i data-feather="plus"></i>New Event</a>
        </div>
    </div>
</div>