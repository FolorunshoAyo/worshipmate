<div id="image-story-modal" class="modal image-story-modal is-medium has-light-bg">
    <div class="modal-background"></div>
    <div class="modal-content">

        <div class="card">
            <div class="card-heading">
                <div class="small-avatar">
                    <img class="avatar" src="https://via.placeholder.com/150x150" data-demo-src="assets/img/avatars/jenna.png" data-user-popover="0" alt="">
                </div>
                <h3>Image Story</h3>
                <!-- Close X button -->
                <div class="close-wrap">
                    <span class="close-modal">
                        <i data-feather="x"></i>
                    </span>
                </div>
            </div>
            <div class="card-body">
                <div class="columns">
                    <div class="column is-6">
                        <div class="story-meta">
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Urgent tamen et nihil remittunt.
                                Sed nimis multa. Sed plane dicit quod intellegit.</p>
                            <div class="field">
                                <div class="control">
                                    <input type="text" class="input is-fade" placeholder="Story title">
                                </div>
                            </div>
                            <div class="field">
                                <div class="control">
                                    <textarea class="textarea is-fade" rows="3" placeholder="Describe your story"></textarea>
                                </div>
                            </div>
                            <div class="field">
                                <div class="control">
                                    <select class="demo" multiple></select>
                                </div>
                            </div>
                            <div class="field">
                                <div class="control buttons">
                                    <button class="button is-light close-modal">Cancel</button>
                                    <button class="button is-solid accent-button raised">Publish Story</button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="column is-6">
                        <div class="story-upload">
                            <div id="image-preview" class="preview-block">
                                <img id="image-upload-placeholder" class="image-upload-placeholder" src="https://cdn.dribbble.com/users/17001/screenshots/5899975/dribbble_11_1x.png" alt="">
                            </div>
                            <div class="input-block">
                                <input id="image-story-upload" type="file" accept=".jpg,.jpeg.,.gif,.png,.mov,.mp4" id="file-input" />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>