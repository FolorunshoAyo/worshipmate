<!-- <link rel="icon" type="image/png" href="assets/img/favicon.png" /> -->

<!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:600,700,800,900" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,500" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/fontisto@v3.0.4/css/fontisto/fontisto-brands.min.css" rel="stylesheet">
    <!-- Core CSS -->
    <link rel="stylesheet" href="<?= $base_url ?>assets/css/app.css">
    <link rel="stylesheet" href="<?= $base_url ?>assets/css/core.css">